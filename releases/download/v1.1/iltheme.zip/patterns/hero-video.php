<?php
/**
 * Title: Hero Video
 * Slug: iltheme/hero-video
 * Categories: featured
 */
?>
<!-- wp:iltheme/hero-video /-->