<?php
/**
 * Title: Previous Posts
 * Slug: iltheme/previous-posts
 * Categories: text
 */
?>
<!-- wp:heading {"level":3} -->
<h3><?php echo esc_html__('Previous posts', 'iltheme'); ?></h3>
<!-- /wp:heading -->