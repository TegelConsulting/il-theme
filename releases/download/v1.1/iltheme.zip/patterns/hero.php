<?php
/**
 * Title: Hero
 * Slug: iltheme/hero
 * Categories: featured
 */
?>
<!-- wp:iltheme/hero /-->